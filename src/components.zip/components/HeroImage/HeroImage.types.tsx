export interface HeroImageProps {
  imageUrl: string;
  headline: string;
  subheadline: string;
  disabled?: boolean;
}