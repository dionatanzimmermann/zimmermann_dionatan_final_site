export interface TextProps {
  children: React.ReactNode;
  disabled?: boolean;
  color?: string;
  fontSize?: string;
}