export interface TableFooterProps {
  children: React.ReactNode;
  disabled?: boolean;
  colSpan?: number;
}