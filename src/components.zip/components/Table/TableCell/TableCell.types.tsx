export interface TableCellProps {
  children: React.ReactNode;
  disabled?: boolean;
  as?: 'td' | 'th';
}