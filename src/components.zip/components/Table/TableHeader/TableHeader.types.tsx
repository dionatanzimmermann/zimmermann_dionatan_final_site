export interface TableHeaderProps {
  children: React.ReactNode;
  disabled?: boolean;
}