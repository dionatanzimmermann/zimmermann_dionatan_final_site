export interface TableRowProps {
  children: React.ReactNode;
  disabled?: boolean;
}