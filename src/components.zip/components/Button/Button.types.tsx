export interface ButtonProps {
  text: string;
  disabled?: boolean;
  onClick?: () => void;
  backgroundColor?: string;
}