export interface LabelProps {
  htmlFor?: string;
  text?: string;
  disabled?: boolean;
}